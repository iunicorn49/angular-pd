import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  private testId:number;
  constructor(
    private routeInfo: ActivatedRoute
  ) { }

  ngOnInit() {
    // 参数订阅: url参数改变就会被调用
    this.routeInfo.params.subscribe((params: Params) => {
      this.testId = params['id']
    });
    // 快照模式: 只有组件重新渲染才会调用
    // this.testId = this.routeInfo.snapshot.params['id'];
  }

}
