import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-stock',
  templateUrl: './stock.component.html',
  styleUrls: ['./stock.component.css']
})
export class StockComponent implements OnInit {
  private stockId:number;
  private isPro:boolean;
  constructor(
    private routeInfo: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.stockId = this.routeInfo.snapshot.queryParams['id'];
    this.isPro = this.routeInfo.snapshot.data[0]['isPro'];
  }

  toBuyer(id) {
    this.router.navigate(['./stock/buyer', id]);
  }

  toSeller(id) {
    this.router.navigate(['./stock/seller', id]);
  }
}
